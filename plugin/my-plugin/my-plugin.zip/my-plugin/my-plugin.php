<?php
/* Plugin Name: My WordPress Plugin
Plugin URI: http://www.miaisoft.com/
Description: Slider Component for WordPress
Version: 1.0
Author: Touhid Mia
Author URI: http://www.hmtmcse.com/
License: GPLv2 or later
*/


function when_trigger_my_plugin_activation(){
//    some code here
}
register_activation_hook(__FILE__, 'when_trigger_my_plugin_activation');


function when_trigger_my_plugin_deactivation() {
//    some code here
}
register_deactivation_hook(__FILE__, 'when_trigger_my_plugin_deactivation');


add_action('wp_enqueue_scripts', 'include_my_plugin_scripts');
function include_my_plugin_scripts() {

    wp_enqueue_script('jquery');
    wp_register_script('my_plugin_slides_js_core', plugins_url('js/jquery.slides.min.js', __FILE__), array("jquery"));
    wp_enqueue_script('my_plugin_slides_js_core');

    wp_register_script('my_plugin_slides_js_init', plugins_url('js/slidesjs.initialize.js', __FILE__));
    wp_enqueue_script('my_plugin_slides_js_init');


    $effect = (get_option('var_my_plugin_slide__effect') == '') ? "slide" : get_option('var_my_plugin_slide_effect');
    $interval = (get_option('var_my_plugin_slide_interval') == '') ? 2000 : get_option('var_my_plugin_slide_interval');
    $auto_play = (get_option('var_my_plugin_slide_auto_play') == 'enabled') ? true : false;
    $play_btn = (get_option('var_my_plugin_slide_play_btn') == 'enabled') ? true : false;
    $config_array = array(
        'effect' => $effect,
        'interval' => $interval,
        'autoplay' => $auto_play,
        'playBtn' => $play_btn
    );
    wp_localize_script('my_plugin_slides_js_init', 'setting', $config_array);

}


add_action('wp_enqueue_scripts', 'include_my_plugin_styles');
function include_my_plugin_styles() {
    wp_register_style('my_plugin_base', plugins_url('css/base.css', __FILE__));
    wp_enqueue_style('my_plugin_base');
    wp_register_style('my_plugin_font-awesome', plugins_url('css/font-awesome.min.css', __FILE__));
    wp_enqueue_style('my_plugin_font');
}



add_shortcode("my_plugin_slider", "include_short_code_my_plugin_slider");
function include_short_code_my_plugin_slider($attr, $content) {
    extract(shortcode_atts(array(
        'id' => ''
    ),$attr));

    $gallery_images = get_post_meta($id, "my_plugin_gallery_images", true);
    $gallery_images = ($gallery_images != '') ? json_decode($gallery_images) : array();

    $html = '<div class="container"><div id="slides">';
    foreach ($gallery_images as $gal_img) {
        if ($gal_img != "") {
            $html .= "<img src='" . $gal_img . "' />";
        }
    }
    $html .= '<a href="#" class="slidesjs-previous slidesjs-navigation"><i class="icon-chevron-left icon-large"></i></a>
              <a href="#" class="slidesjs-next slidesjs-navigation"><i class="icon-chevron-right icon-large"></i></a></div></div>';
    return $html;
}


add_action('init', 'register_my_plugin_slider');
function register_my_plugin_slider() {
    $labels = array(
        'menu_name' => _x('Sliders', 'my_plugin_slider'),
    );
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'Slide Shows',
        'supports' => array('title', 'editor'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );
    register_post_type('my_plugin_slider', $args);
}


add_action('add_meta_boxes', 'my_plugin_slider_meta_box');
function my_plugin_slider_meta_box() {
    add_meta_box("my_plugin_slider_images", "Slider Images", 'my_plugin_slider_images_callback', "my_plugin_slider", "normal");
}

function my_plugin_slider_images_callback() {
    global $post;
    $gallery_images = get_post_meta($post->ID, "my_plugin_gallery_images", true);
    $gallery_images = ($gallery_images != '') ? json_decode($gallery_images) : array();
    $html = '<input type="hidden" name="my_plugin_slider_bok_key" value="' . wp_create_nonce(basename(__FILE__)) . '" />';

    $html .= '<table class="form-table">';
    $html .= "
          <tr>
            <th style=''><label for='Upload Images'>Image 1</label></th>
            <td><input name='my_plugin_slider_img[]' id='fwds_slider_upload' type='text' value='" . $gallery_images[0] . "'  /></td>
          </tr>
          <tr>
            <th style=''><label for='Upload Images'>Image 2</label></th>
            <td><input name='my_plugin_slider_img[]' id='fwds_slider_upload' type='text' value='" . $gallery_images[1] . "' /></td>
          </tr>
          <tr>
            <th style=''><label for='Upload Images'>Image 3</label></th>
            <td><input name='my_plugin_slider_img[]' id='fwds_slider_upload' type='text'  value='" . $gallery_images[2] . "' /></td>
          </tr>
          <tr>
            <th style=''><label for='Upload Images'>Image 4</label></th>
            <td><input name='my_plugin_slider_img[]' id='fwds_slider_upload' type='text' value='" . $gallery_images[3] . "' /></td>
          </tr>
          <tr>
            <th style=''><label for='Upload Images'>Image 5</label></th>
            <td><input name='my_plugin_slider_img[]' id='fwds_slider_upload' type='text' value='" . $gallery_images[4] . "' /></td>
          </tr>

        </table>";
    echo $html;
}


add_action('save_post', 'my_plugin_slider_images_save');
function my_plugin_slider_images_save($post_id) {
    if (!wp_verify_nonce($_POST['my_plugin_slider_bok_key'], basename(__FILE__))) {
        return $post_id;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    // check permissions
    if ('my_plugin_slider' == $_POST['post_type'] && current_user_can('edit_post', $post_id)) {
        $gallery_images = (isset($_POST['my_plugin_slider_img']) ? $_POST['my_plugin_slider_img'] : '');
        $gallery_images = strip_tags(json_encode($gallery_images));
        update_post_meta($post_id, "my_plugin_gallery_images", $gallery_images);
    } else {
        return $post_id;
    }
}


add_action('admin_menu', 'my_plugin_slider_settings');
function my_plugin_slider_settings() {
    add_menu_page('My Plugin Slider', 'My Plugin Slider', 'administrator', 'my_plugin_settings', 'my_plugin_slider_settings_callback');
}

function my_plugin_slider_settings_callback() {

    $slide_effect = (get_option('var_my_plugin_slide__effect') == 'slide') ? 'selected' : '';
    $fade_effect = (get_option('var_my_plugin_slide__effect') == 'fade') ? 'selected' : '';
    $interval = (get_option('var_my_plugin_slide_interval') != '') ? get_option('fwds_interval') : '2000';
    $autoplay  = (get_option('var_my_plugin_slide_auto_play') == 'enabled') ? 'checked' : '' ;
    $playBtn  = (get_option('var_my_plugin_slide_play_btn') == 'enabled') ? 'checked' : '' ;

    $html = '<div class="wrap">
            <form method="post" name="options" action="options.php">
            <h2>Select Your Settings</h2>' . wp_nonce_field('update-options') . '
            <table width="100%" cellpadding="10" class="form-table">
                <tr>
                    <td align="left" scope="row">
                    <label>Slider Effect</label>
                    <select name="var_my_plugin_slide__effect" >
                      <option value="slide" ' . $slide_effect . '>Slide</option>
                      <option value="fade" '.$fade_effect.'>Fade</option>
                    </select>
                    </td>
                </tr>
                <tr>
                    <td align="left" scope="row">
                    <label>Enable Auto Play</label><input type="checkbox" '.$autoplay.' name="var_my_plugin_slide_auto_play"
                    value="enabled" />

                    </td>
                </tr>
                <tr>
                    <td align="left" scope="row">
                    <label>Enable Play Button</label><input type="checkbox" '.$playBtn.' name="var_my_plugin_slide_play_btn"
                    value="enabled" />

                    </td>
                </tr>
                <tr>
                    <td align="left" scope="row">
                    <label>Transition Interval</label><input type="text" name="var_my_plugin_slide_interval"
                    value="' . $interval . '" />

                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="hidden" name="action" value="update" />
                <input type="hidden" name="page_options" value="var_my_plugin_slide_auto_play,var_my_plugin_slide__effect,var_my_plugin_slide_interval,var_my_plugin_slide_play_btn" />
                <input type="submit" name="Submit" value="Update" />
            </p>
            </form>

        </div>';
    echo $html;
}


?>